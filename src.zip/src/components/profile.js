

const profileEditButton = document.querySelector('.profile__edit-button');

profileEditButton.addEventListener('click', () => {
	openPopup();
});