const popup = document.querySelectorAll('.popup');

const openPopup = () => {
	popup.forEach((item) => {
		item.classList.toggle('popup_is-opened');
	});
};
export { openPopup, popup };