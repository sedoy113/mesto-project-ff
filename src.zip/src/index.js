import './pages/index.css';
import './images/logo.svg';
import './images/avatar.jpg';

import { addCardsToList } from './components/card.js';

// 

const popupElement = document.querySelectorAll('.popup');
const popupClose = document.querySelector('.popup__close');


const openPopup = (popup) => {
	popup.forEach(element => {
		element.classList.toggle('popup_is-opened');
	});
};

const profileEditButton = document.querySelector('.profile__edit-button');
const profileAddButton = document.querySelector('.profile__add-button');

const handleProfileEditButtonClick = () => {
	openPopup(popupElement);
};

popupClose.addEventListener('click', () => openPopup(popupElement));

profileEditButton.addEventListener('click', handleProfileEditButtonClick);


profileAddButton.addEventListener('click', handleProfileEditButtonClick);
